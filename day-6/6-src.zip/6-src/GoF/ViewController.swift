//
//  ViewController.swift
//  GoF
//
//  Sample skeleton code for Game of Fifteen
//  Provided July 5 in class.
//
//  Created by Dan Armendariz on 7/5/16.
//  Copyright © 2016 Dan Armendariz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var boardView: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // generate a random board
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tileTapped(sender: UIButton)
    {
            print("ohai!")
    }

    override func viewDidAppear(animted: Bool)
    {
        let tileSize = CGFloat(32.0)
        let rect = CGRect(x: 0.0, y: 0.0, width: tileSize, height: tileSize)
        let newTile = UIButton(frame: rect)
        
        newTile.setTitle("1", forState: UIControlState.Normal)
        
        newTile.layer.borderColor = UIColor.blackColor().CGColor
        newTile.layer.borderWidth = 2
        
        // add a shadow!!!!!
        newTile.layer.shadowRadius = 2
        newTile.layer.shadowColor = UIColor.blackColor().CGColor
        newTile.layer.shadowOffset = CGSizeMake(2.0, 2.0)
        newTile.layer.shadowOpacity = 0.5

        newTile.addTarget(self, action: #selector(ViewController.tileTapped(_:)), forControlEvents: UIControlEvents.TouchUpInside)

        
        boardView.addSubview(newTile)
    }
    
}

