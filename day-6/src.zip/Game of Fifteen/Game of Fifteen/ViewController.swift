//
//  ViewController.swift
//  Game of Fifteen
//
//  Created by Dan Armendariz on 7/21/15.
//  Copyright (c) 2015 Dan Armendariz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var board: [[Int]] = []
    /* Game of Fifteen exercise code here */
    
    @IBOutlet weak var boardView: UIView!
    
    // create an array of tiles
    var tiles: [UIButton] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Generate a random board
    }
    
    func tileTapped(sender: UIButton)
    {
        println(sender.tag)

        // var temp = tiles[sender.tag].frame
        // tileA.frame = tile[/* tag of the empty tile */].frame
        // tileB.frame = temp
    }
    
    override func viewWillAppear(animated: Bool) {
        let borderWidth = CGFloat(2.0)
        let tileSize = boardView.bounds.size.width / 4.0  - CGFloat(14.0)

        
        let rect = CGRect(x: 0.0, y: 0.0, width: tileSize, height: tileSize)
        
        var newTile = UIButton(frame: rect)
        
        // set the caption of the button
        newTile.setTitle("0", forState: UIControlState.Normal)
        
        // let the button know which tile it is
        newTile.tag = 0
        
        // change the background color of the tile
        newTile.backgroundColor = UIColor.lightGrayColor()
        
        // set a border
        newTile.layer.borderColor = UIColor.blackColor().CGColor
        newTile.layer.borderWidth = borderWidth
        
        // add a shadow!!!!!
        newTile.layer.shadowRadius = 2
        newTile.layer.shadowColor = UIColor.blackColor().CGColor
        newTile.layer.shadowOffset = CGSizeMake(2.0, 2.0)
        newTile.layer.shadowOpacity = 0.5
        
        newTile.addTarget(self, action: "tileTapped:", forControlEvents: UIControlEvents.TouchUpInside)
        
        // remember this tile for later use
        tiles.append(newTile)
        
        // add the tile to the board
        boardView.addSubview(newTile)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

