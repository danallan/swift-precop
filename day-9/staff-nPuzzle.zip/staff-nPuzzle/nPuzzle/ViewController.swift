//
//  ViewController.swift
//  nPuzzle
//
//  Created by Dan Armendariz on 7/20/15.
//  Copyright (c) 2016 Dan Armendariz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // some constants to define various board sizes
    let DIFFICULTIES = [
        (title: "Baby", rating: "👶🏽", size: 2),
        (title: "Easy", rating: "⭐️", size: 3),
        (title: "Medium", rating: "⭐️⭐️", size: 4),
        (title: "Hard", rating: "⭐️⭐️⭐️", size: 5),
        (title: "Insane", rating: "😈", size: 7)
    ]
    
    // half the number of radians for insane boards to rotate
    let ROTATE_LEFT = CGAffineTransformMakeRotation(CGFloat(M_PI / 5.0))
    let ROTATE_RIGHT = CGAffineTransformMakeRotation(CGFloat(M_PI / -5.0))
    let ROTATE_CENTER = CGAffineTransformMakeRotation(0.0)
    
    // used throughout for the number of tiles
    var PUZZLE_SIZE = 0
    var NUMBER_TILES = 0
    var EMPTY_TILE = 0
    
    /* board model: given a tile's value on the board,
     * lookup will store a tuple of the row and col
     * of that value's location on the game board.
     */
    typealias Position = (row: Int, col: Int)
    typealias TilePositions = [Position]
    var lookup: TilePositions = []
    
    // shuffling board model
    typealias Tiles = [Int]
    
    // UI button lookup based on their tile number
    var tiles: [UIButton] = []
    
    // winning
    let congrats = ["🎈","👍🏼","🎉","👏🏾","😎","🎊","💐"]
    var hasWon = false
    @IBOutlet weak var winLabel: UILabel!

    // keep track of moves
    var moves = 0
    var minMoves: Int?

    // disallow moves (for animation, countdown, etc)
    var boardLock = false
    
    // duration of tile swap animation
    let SWAP_INTERVAL = NSTimeInterval(0.2)
    
    // timer
    var COUNTDOWN = 3
    var timeRemaining = 0
    @IBOutlet weak var timerLabel: UILabel!
    
    // ref to views
    @IBOutlet weak var boardView: UIView!
    @IBOutlet weak var movesLabel: UILabel!
    @IBOutlet weak var minLabel: UILabel!
    @IBOutlet weak var difficultyButton: UIButton!

    
    /********************/
    /** GAME MECHANICS **/
    /********************/
    
    /* indexToPosition()
     * Convert an integer index into a tuple
     * corresponding to the row and column on the board. 
     */
    func indexToPosition(index: Int) -> Position
    {
        return (row: index / PUZZLE_SIZE, col: index % PUZZLE_SIZE)
    }
    
    /* positionToIndex()
     * Converts a tuple representing the row and column
     * of a board location into a 0-based index. 
     */
    func positionToIndex(pos: Position) -> Int
    {
        return pos.row * PUZZLE_SIZE + pos.col
    }

    /* won()
     * Returns true if the provided two-dimensional board
     * is in a winning configuration; false otherwise.
     */
    func won() -> Bool
    {
        for i in 0 ..< NUMBER_TILES
        {
            let pos = lookup[i]
            if positionToIndex(pos) != i
            {
                return false
            }
        }

        return true
    }
    
    /* validMove()
     * Given a value on a board, returns true if the
     * Manhattan distance from the tile represented by
     * that tile is exactly 1 from the empty tile.
     * Returns false otherwise.
     */
    func validMove(value: Int) -> Bool
    {
        let empty = lookup[EMPTY_TILE]
        let tile = lookup[value]

        return (abs(empty.row - tile.row) + abs(empty.col - tile.col)) == 1
    }

    
    /*********************/
    /** Action handlers **/
    /*********************/

    
    /* tileTapped()
     * Handler for any tapped view that represents a tile.
     * Checks for a valid move and will initiate a swap
     * on valid moves, then checks for a winning board.
     */
    func tileTapped(tile: UIButton)
    {
        // abort if tiles are swapping or move is invalid
        if boardLock || !validMove(tile.tag)
        {
            return
        }

        // move is valid: track moves
        moves += 1
        movesLabel.text = String(moves)
        
        // perform swap
        let empty = boardView.viewWithTag(EMPTY_TILE)!
        swapTile(tile, to: empty, animate: true)
        
        // check if user has won
        if won()
        {
            // update minimum moves
            if minMoves == nil || moves < minMoves!
            {
                minMoves = moves
                minLabel.text = "Best: \(minMoves!)"
            }

            // yay!
            congratulate()
        }
    }
    
    /* reshuffleRequest()
     * Reshuffle the board. An alert will appear if the
     * user is mid-game, or the board will be shuffled
     * immediately if the user has just won.
     */
    @IBAction func reshuffleRequest(sender: AnyObject) {
        // no reshuffling allowed when the board is locked
        if boardLock
        {
            return
        }

        // bypass confirmation if the user has won
        if hasWon
        {
            reset()
            shuffle()
            return
        }

        // construct the alert asking user if they want to shuffle
        let alert = UIAlertController(title: "Shuffle?",
            message: "Would you like to reshuffle the board and start over?",
            preferredStyle: .Alert)

        // cancel button and action (do nothing)
        let cancel = UIAlertAction(title: "Cancel", style: .Cancel)
            { (action) in
                return
            }
        alert.addAction(cancel)

        // accept action (reset and shuffle)
        let accept = UIAlertAction(title: "Shuffle", style: .Default)
            { (action) in
                self.reset()
                self.shuffle()
            }
        alert.addAction(accept)

        // display alert
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    /* changeDifficulty()
     * Displays an action sheet to query the user for a
     * change of difficulty. Game will reset with a new
     * difficulty if one is selected.
     */
    @IBAction func changeDifficulty(sender: AnyObject) {
        // construct an action sheet
        let alert = UIAlertController(title: nil, message: "What difficulty would you like?", preferredStyle: .ActionSheet)

        // add a cancel button
        let cancel = UIAlertAction(title: "Cancel", style: .Cancel)
            { (action) in
                return
            }
        alert.addAction(cancel)

        // add a button for every difficulty
        for level in DIFFICULTIES
        {
            let action = UIAlertAction(title: level.title, style: .Default)
                { (action) in
                    self.setDifficulty(level)
                }
            alert.addAction(action)
        }

        // display action sheet
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    
    /********************
     ** Board handling **
     ********************/
    
    /* printBoard(_:)
     * Prints a one-dimensional board to the console.
     */
    func printBoard(board: Tiles)
    {
        for (i, tile) in board.enumerate()
        {
            let s = tile == EMPTY_TILE ? "__ " : String(format: "%2d ", tile+1)
            print(s, terminator: "")
            
            if (i+1) % PUZZLE_SIZE == 0
            {
                print()
            }
        }
    }
    
    /* printBoard(_:)
     * Prints a TilePositions board to the console.
     */
    func printBoard(board: TilePositions)
    {
        var tiles = [Int](count: board.count, repeatedValue: 0)
        for (tile, pos) in board.enumerate()
        {
            tiles[positionToIndex(pos)] = tile
        }
        printBoard(tiles)
    }
    
    /* swapTile()
     * Swaps two UIViews representing tiles and also ensures
     * the underlying representation of the UI via the
     * `lookup` variable is updated to match the change. 
     * Tile swaps can either be animated or happen instantly.
     */
    func swapTile(from: UIView, to: UIView, animate: Bool)
    {
        // moving the tiles on screen is as simple as swapping frames
        let frameA = from.frame
        let frameB = to.frame
        
        // swap the position in the lookup array
        swap(&lookup[from.tag], &lookup[to.tag])

        if animate
        {
            // animate the swap, locking the board until done
            boardLock = true
            UIView.animateWithDuration(SWAP_INTERVAL,
                animations: { () -> Void in
                    from.frame = frameB
                    to.frame = frameA
                },
                completion: { Bool -> Void in
                    self.boardLock = false
                })
        }
        else
        {
            // immediately swap positions without animation
            from.frame = frameB
            to.frame = frameA
        }
    }
    
    /* shuffle()
     * Shuffles the tiles on the board with the Fisher-Yates
     * algorithm, and ensures the underlying representation of
     * the tiles (via `lookup`) is updated to match the UI.
     */
    func shuffle()
    {
        // keep track of tile values (only used for validation)
        var board: Tiles = Array(0 ..< NUMBER_TILES)
        
        // Perform the Fisher-Yates shuffle
        for n in 0 ..< NUMBER_TILES - 1
        {
            // count backwards
            let tile = EMPTY_TILE - n
            
            // generate a random index from [0,tile] to swap the current
            let rand = Int(arc4random_uniform(UInt32(tile + 1)))
            
            // don't needlessly swap
            if (tile == rand)
            {
                continue
            }
            
            // swap the tiles on the board
            swapTile(tiles[board[tile]], to: tiles[board[rand]], animate: false)
            
            // also keep track of tile values for board validation
            swap(&board[tile], &board[rand])
        }

        // Step 3: fix a broken board by swapping first two tiles
        if Staff.isBoardSolvable(board)! == false
        {
            swapTile(tiles[0], to: tiles[1], animate: false)
        }
    }
    
    /* reset()
     * Removes all existing tiles from the board (if any),
     * Generates new tiles in sequence and adds them to
     * the board, while resetting various game properties
     * and underlying game state.
     */
    func reset()
    {
        // user hasn't won if we're just getting started
        hasWon = false
        
        // stop previous animations to countdown timer
        timerLabel.layer.removeAllAnimations()
        
        // ensure game board is visible
        winLabel.alpha = 0
        boardView.alpha = 1

        // set number of moves to blank
        movesLabel.text = ""
        moves = 0
        
        // delete tiles, if any
        var _ = tiles.map({ $0.removeFromSuperview() })
        
        // reset arrays
        lookup = []
        tiles = []
        
        // calculate the size of each tile based on parent view
        let tileSize = ceil((boardView.bounds.size.width - CGFloat(16)) / CGFloat(PUZZLE_SIZE))
        
        // generate all tiles
        for tileNum in 0 ..< NUMBER_TILES
        {
            // generate the (row, col) coordinate from the tile number
            let pos = indexToPosition(tileNum)
            
            // create the frame based on placement
            let top = CGFloat(pos.row) * tileSize + 8
            let left = CGFloat(pos.col) * tileSize + 8
            let rect = CGRect(x: left, y: top, width: tileSize, height: tileSize)
            
            let newTile = UIButton(frame: rect)
            
            // tile's tag is its value
            newTile.tag = tileNum
            
            // set style for empty vs numbered tiles
            if tileNum == EMPTY_TILE
            {
                // no title or bgcolor
                newTile.setTitle(nil, forState: UIControlState.Normal)
                newTile.backgroundColor = nil
            }
            else
            {
                // apply some decoration to a numbered tile
                newTile.setTitle(String(tileNum + 1), forState: UIControlState.Normal)
                newTile.backgroundColor = UIColor.lightGrayColor()
                
                // set border
                newTile.layer.borderWidth = 2
                newTile.layer.borderColor = UIColor.blackColor().CGColor
            }
            
            // caption color
            newTile.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
            
            // execute a function when a tile is touched
            newTile.addTarget(self, action: #selector(ViewController.tileTapped(_:)), forControlEvents: UIControlEvents.TouchUpInside)
            
            // add the coords for the tile w/ this value to lookup
            lookup.append(pos)
            
            // remember the tile with this value
            tiles.append(newTile)
            
            // add the tile to the board
            boardView.addSubview(newTile)
        }
        
    }
    
    
    /****************************
     ** User Interface Methods **
     ****************************/
    
    
    /* congratulate()
     * Show some UI animations and a congratulatory message.
     */
    func congratulate()
    {
        hasWon = true
        
        // hide the empty tile for now
        tiles[EMPTY_TILE].layer.borderWidth = 0
        
        // pick a random congratulatory emoji
        let pick = Int(arc4random_uniform(UInt32(congrats.count)))
        winLabel.text = congrats[pick]
        
        func animate()
        {
            // hide the game board
            boardView.alpha = 0
            winLabel.alpha = 1
            
            // width and height of the screen
            let width = self.view.bounds.width
            let height = self.view.bounds.height
            
            // create an animation for every tile
            for tile in self.tiles {
                // don't animate the empty tile
                if tile.tag == EMPTY_TILE
                {
                    continue
                }
                
                // randomly pick a rotation for a transform
                let r = CGFloat(Double(arc4random_uniform(720)) * M_PI / 180.0)
                let transform = CGAffineTransformMakeRotation(r)
                
                // randomly pick a scaling factor and chain the transform
                let s = CGFloat(Double(arc4random_uniform(30) + 10) / 10.0)
                tile.transform = CGAffineTransformScale(transform, s, s)
                
                // make the tile go elsewhere
                let dx = CGFloat(Double(arc4random_uniform(UInt32(width * 2.0))) - Double(width))
                let dy = CGFloat(Double(arc4random_uniform(UInt32(width * 2.0))) - Double(height))
                tile.frame = CGRectOffset(tile.frame, dx, dy)
                
                // tile should disappear
                tile.alpha = 0.0
                
                // make sure the label stays centered
                tile.layoutIfNeeded()
                
            }
        }
        
        // perform the animation (with a delay since tile might be sliding)
        UIView.animateWithDuration(1.5,
            delay: SWAP_INTERVAL,
            options: .CurveEaseOut,
            animations: animate,
            completion: nil)
        
    }
    
    /* shuffleTimer()
     * Show a countdown timer before shuffling the board
     * and allowing the user to play.
     */
    func shuffleTimer()
    {
        if timeRemaining > 0
        {
            // while we have time remaining, lock the board
            boardLock = true
            
            // reset properties of the label
            timerLabel.alpha = 1
            timerLabel.transform = CGAffineTransformMakeScale(1.0, 1.0)
            timerLabel.text = String(timeRemaining)
            timerLabel.hidden = false
            
            timeRemaining -= 1
            
            // shrink the label for 1s, then call this function again
            UIView.animateWithDuration(1,
                delay: 0,
                options: .CurveLinear,
                animations: { () -> Void in
                    self.timerLabel.transform = CGAffineTransformMakeScale(0.1, 0.1)
                    self.timerLabel.alpha = 0
                },
                completion: { (finished) -> Void in
                    // only do the following when animation fully complete
                    if finished
                    {
                        self.timerLabel.hidden = true
                        self.shuffleTimer()
                    }
                })
            
            return
        }
        
        // no more time remaining: shuffle ..
        shuffle()
        
        // .. and unlock it to begin
        boardLock = false
    }
    
    /* setDifficulty()
     * Given a difficulty tuple, reset the board,
     * kickstart the process to generate a new one,
     * and display the countdown timer.
     */
    func setDifficulty(difficulty: (title: String, rating: String, size: Int))
    {
        // set the width and height of the board
        PUZZLE_SIZE = difficulty.size

        // total number of tiles
        NUMBER_TILES = PUZZLE_SIZE * PUZZLE_SIZE
        
        // the value representing the empty tile
        EMPTY_TILE = NUMBER_TILES - 1

        difficultyButton.setTitle(difficulty.rating, forState: UIControlState.Normal)
        minLabel.text = ""

        // generate all new tiles given the new board size
        reset()

        // difficult boards also swing!
        if (difficulty.size > 5)
        {
            boardView.transform = ROTATE_LEFT
            UIView.animateWithDuration(2,
                delay: 0,
                options: [.Repeat, .Autoreverse, .AllowUserInteraction],
                animations: { () -> Void in
                    self.boardView.transform = self.ROTATE_RIGHT
                },
                completion: { (finished) -> Void in
                    if !finished
                    {
                        self.boardView.transform = self.ROTATE_CENTER
                    }
            })
        }
        else
        {
            // reset board animation
            boardView.layer.removeAllAnimations()
        }

        // prep for game play
        timeRemaining = COUNTDOWN
        shuffleTimer()
        
    }
    
    
    /***************************
     ** Application lifecycle **
     ***************************/

    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)

        // set a default board size and begin creating objects
        setDifficulty(DIFFICULTIES[2])
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // make the board look like a board
        boardView.layer.borderColor = UIColor.blackColor().CGColor
        boardView.layer.borderWidth = 8
        boardView.layer.cornerRadius = 8
        boardView.layer.shadowRadius = 8
        boardView.layer.shadowColor = UIColor.blackColor().CGColor
        boardView.layer.shadowOffset = CGSizeMake(5.0, 5.0)
        boardView.layer.shadowOpacity = 0.8
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

