/* Dan Armendariz
 * danallan@cs.harvard.edu
 *
 * Staff-supplied (hidden) functions for game of fifteen exercises.
 */

import Darwin

public class Staff {

    /* sign()
     * Finds the sign of the permutation of the board.
     * from: http://cseweb.ucsd.edu/~ccalabro/essays/15_puzzle.pdf
     * parameter a: [Int] (tiles themselves are 0-indexed, with empty being max)
     * returns 1 if odd, 0 if even
     */
    private static func sign(var a: [Int]) -> Int
    {
        var s = 0, i = 0, tmp: Int
        
        while i < a.count
        {
            if i != a[i]
            {
                tmp = a[i]
                a[i] = a[tmp]
                a[tmp] = tmp
                s = 1 - s
            }
            else
            {
                i++
            }
        }
        return s
    }
    
    /* isBoardSolvable
     * accepts a board with tiles from [1, board.count], massages it for
     * _sign() by converting tiles to [0, board.count), locates the empty
     * tile and ensures the sign of the permutation of the board matches
     * the sign of the distance of the empty tile. Returns true if board
     * is solvable, false otherwise.
     */
    public static func isBoardSolvable(board: [Int]) -> Bool
    {
        // the width and height of the board
        let size = Int(sqrt(Double(board.count)))
        
        if let index = find(board, board.count - 1)
        {
            // compute empty tile's distance to its final location
            let empty = (x: index / size, y: index % size)
            let last = (x: size-1, y: size-1)
            let dist = abs(empty.x - last.x) + abs(empty.y - last.y)
            
            // puzzle is valid if sign of the permutation matches that of empty dist
            return self.sign(board) == (dist % 2)
        }
        
        // if we're here, we couldn't find empty tile :(
        return false
    }

    /*
     * isBoardSolvable() for two-dimensional boards.
     */
    public static func isBoardSolvable(board: [[Int]]) -> Bool
    {
        // flatten the board to a 1d array
        return self.isBoardSolvable(board.flatMap({ $0 }))
    }
    
}
