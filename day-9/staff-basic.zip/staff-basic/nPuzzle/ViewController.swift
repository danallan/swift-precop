//
//  ViewController.swift
//  nPuzzle
//
//  Created by Dan Armendariz on 7/20/15.
//  Copyright (c) 2015 Dan Armendariz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    // some constants to define various board sizes
    let DIFFICULTY_EASY = 9
    let DIFFICULTY_MED = 16
    let DIFFICULTY_HARD = 25

    // used throughout for the number of tiles
    var PUZZLE_SIZE = 0
    var EMPTY_TILE = 0
    
    // board model
    var board: [[Int]] = [[]]
    var moves = 0
    
    // button views
    var tileSize = CGFloat(0.0)
    var animating = false
    
    // ref to views
    @IBOutlet weak var boardView: UIView!

    
    /**** GAME MECHANICS *****/
    
    /* won()
     * Returns true if the provided two-dimensional board
     * is in a winning configuration; false otherwise.
     */
    func won(board: [[Int]]) -> Bool
    {
        for i in 0 ..< EMPTY_TILE
        {
            if board[i / 4][i % 4] != i + 1
            {
                return false
            }
        }
        return true
    }

    /* validMove()
     * Given a two-dimensional board, returns true if the
     * Manhattan distance from a tile (specified by the
     * provided row and col) to the empty tile is exactly 1.
     * Returns false otherwise.
     */
    func validMove(board: [[Int]], row: Int, col: Int) -> Bool
    {
        if row < 0 || row >= PUZZLE_SIZE || col < 0 || col >= PUZZLE_SIZE
        {
            return false
        }
        
        // find empty
        for rowIndex in 0 ..< board.count
        {
            for colIndex in 0 ..< board[rowIndex].count
            {
                if board[rowIndex][colIndex] == EMPTY_TILE
                {
                    return (abs(row - rowIndex) + abs(col - colIndex)) == 1
                }
            }
        }
        
        return false
    }

    /* slideTile()
     * Given a two-dimensional board and a tile (specified by
     * a row and col), will return a modified board with
     * that tile swapped with the empty tile, if the move
     * is valid. If invalid, the board will remain unmodified.
     */
    func slideTile(var board: [[Int]], row: Int, col: Int) -> [[Int]]
    {
        // Step 1: determine if move is valid
        if !validMove(board, row: row, col: col)
        {
            return board
        }

        // Step 2: perform swap
        for rowIndex in 0 ..< board.count
        {
            for colIndex in 0 ..< board[rowIndex].count
            {
                if board[rowIndex][colIndex] == EMPTY_TILE
                {
                    moveTileWithTag(board[row][col])

                    swap(&board[rowIndex][colIndex], &board[row][col])
                    
                    // Step 3: check if user has won
                    if won(board)
                    {
                        // Step 4: congratulate user
                        println("Congratulations, you win!")
                    }
                    
                    // Step 5: Return modified game board
                    return board
                }
            }
        }
        
        return board
    }


    /* swapTilesOneAndTwo()
     * Finds the tiles numbered 1 and 2 and swaps them.
     */
    func swapTilesOneAndTwo(var board: [[Int]]) -> [[Int]]
    {
        for rowIndex in 0 ..< board.count
        {
            for colIndex in 0 ..< board[rowIndex].count
            {
                switch board[rowIndex][colIndex]
                {
                case 1:
                    board[rowIndex][colIndex] = 2
                case 2:
                    board[rowIndex][colIndex] = 1
                default: break
                }
            }
        }
        return board
    }

    /* generateBoard()
     * Creates and returns a valid, solvable, game of
     * fifteen board represented by a two-dimensional array.
     */
    func generateBoard() -> [[Int]]
    {
        // create a blank board
        var board: [[Int]] = [[]]
        
        // Step 1: generate a won board with tiles from 1 to 16
        for i in 0 ..< EMPTY_TILE
        {
            let rowIndex = i / PUZZLE_SIZE
            
            // append a new row if it doesn't exist yet
            if rowIndex == board.count
            {
                board.append([])
            }
            
            // append the value into the row
            board[rowIndex].append(i + 1)
        }
        
        // Step 2: perform the Fisher-Yates shuffle
        for n in 0 ..< EMPTY_TILE
        {
            // count backwards
            let tile = EMPTY_TILE - 1 - n
            
            // figure out the current row and column from tile
            let row = tile / PUZZLE_SIZE
            let col = tile % PUZZLE_SIZE
            
            // generate a random row and column to swap the current tile
            // ugh why does a4r_u only accept UInt32
            let rrow = Int(arc4random_uniform(UInt32(PUZZLE_SIZE)))
            let rcol = Int(arc4random_uniform(UInt32(PUZZLE_SIZE)))
            
            // complete the swap
            swap(&board[row][col], &board[rrow][rcol])
        }
        
        // Step 3: fix a broken board
        if !Staff.isBoardSolvable(board)
        {
            board = swapTilesOneAndTwo(board)
        }
        
        // Step 4: return the completed board
        return board
    }

    // Set the size of the board
    func setDifficulty(size: Int)
    {
        EMPTY_TILE = size
        PUZZLE_SIZE = Int(sqrt(Double(size)))
    }

    
    /**** Controlling views ****/
    
    // Action handler for press events
    func tileTapped(sender: UIButton)
    {
        // abort if we're currently swapping some tiles
        if animating
        {
            return
        }

        // find the tile on th board
        for row in 0 ..< board.count
        {
            for col in 0 ..< board[row].count
            {
                if board[row][col] == sender.tag
                {
                    // move the tile
                    board = slideTile(board, row: row, col: col)
                    return
                }
            }
        }
    }

    // when requested by slideTile, move the UI views
    func moveTileWithTag(tag: Int)
    {
        animating = true

        var empty = boardView.viewWithTag(EMPTY_TILE)!
        var tile = boardView.viewWithTag(tag)!

        // animate the empty tile behind the numbered one
        boardView.sendSubviewToBack(empty)
        
        // moving the tiles is as simple as swapping their frames
        let emptyFrame = empty.frame
        let tileFrame = tile.frame

        // animate the frame swaps
        UIView.animateWithDuration(0.3, animations: { () -> Void in
            tile.frame = emptyFrame
            empty.frame = tileFrame
        }, completion: { Bool -> Void in
            self.animating = false
        })
        
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        
        // tileSize is sufficient with square tiles
        tileSize = ceil((boardView.bounds.size.width - CGFloat(16)) / CGFloat(PUZZLE_SIZE))
        
        // generate all tiles (except the empty)
        for row in 0 ..< PUZZLE_SIZE
        {
            for col in 0 ..< PUZZLE_SIZE
            {
                let tile = board[row][col]
                let top = CGFloat(row) * tileSize + 8
                let left = CGFloat(col) * tileSize + 8
                let rect = CGRect(x: left, y: top, width: tileSize, height: tileSize)
                var newTile = UIButton(frame: rect)

                // have this tile remember its value
                newTile.tag = tile
                
                // set the button styles
                if tile != EMPTY_TILE
                {
                    newTile.setTitle(String(tile), forState: UIControlState.Normal)
                    newTile.setTitleColor(UIColor.blackColor(), forState: UIControlState.Normal)
                    newTile.backgroundColor = UIColor.lightGrayColor()

                    // allow the tile to be tapped
                    newTile.addTarget(self, action: "tileTapped:", forControlEvents: UIControlEvents.TouchUpInside)

                }

                // set border for all tiles
                newTile.layer.borderWidth = 2
                newTile.layer.borderColor = UIColor.blackColor().CGColor
                
                // add the tile to the board
                boardView.addSubview(newTile)
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // set default board size
        setDifficulty(DIFFICULTY_MED)
        
        board = generateBoard()

        // make the board look like a board
        boardView.layer.borderColor = UIColor.blackColor().CGColor
        boardView.layer.borderWidth = 8
        boardView.layer.cornerRadius = 8
        boardView.layer.shadowRadius = 8
        boardView.layer.shadowColor = UIColor.blackColor().CGColor
        boardView.layer.shadowOffset = CGSizeMake(4.0, 4.0)
        boardView.layer.shadowOpacity = 0.8

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

