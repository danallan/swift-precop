{
  "album": "Travel album",
  "photos": [
    {
      "name": "Icelandic Waterfall",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/26@2x.jpg"
    },
    {
      "name": "Hot spring",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/27@2x.jpg"
    },
    {
      "name": "White out",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/28@2x.jpg"
    },
    {
      "name": "Grand Canyon",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/29@2x.jpg"
    },
    {
      "name": "Fjords, Boats, and Falls",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/30@2x.jpg"
    },
    {
      "name": "Grand Canyon Silhouette",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/31@2x.jpg"
    },
    {
      "name": "Joshua Tree",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/32@2x.jpg"
    },
    {
      "name": "Stamsund, Norway",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/33@2x.jpg"
    },
    {
      "name": "Lofoten",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/34@2x.jpg"
    },
    {
      "name": "Jump?",
      "url": "http://docs.danallan.net/cs50/swift/ios4-img/35@2x.jpg"
    }
  ]
}
