//
//  ViewController.swift
//  ios3
//
//  Created by Dan Armendariz on 11/20/14.
//  Copyright (c) 2014 Dan Armendariz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var photoView: UIImageView!
    @IBOutlet weak var imageButton: UIBarButtonItem!
    
    @IBAction func navigate(sender: AnyObject) {
        photoView.image = UIImage(named: "lofoten.jpg")
        
        imageButton.title = "Woo!"
        imageButton.enabled = false
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

