//
//  ViewController.swift
//  Game of Fifteen
//
//  Created by Dan Armendariz on 7/21/15.
//  Copyright (c) 2015 Dan Armendariz. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var board: [[Int]] = []
    /* Game of Fifteen exercise code here */
    
    @IBOutlet weak var countdownLabel: UILabel!
    var countdown = 3
    
    var animating = false
    
    @IBOutlet weak var boardView: UIView!
    
    // create an array of tiles
    var tiles: [UIButton] = []
    

    func startTimer(interval: Int)
    {
        NSTimer.scheduledTimerWithTimeInterval(NSTimeInterval(interval), target: self, selector: Selector("timerFired"), userInfo: nil, repeats: false)
    }
    
    func timerFired()
    {
        countdown--
        
        if countdown == -1
        {
            countdownLabel.hidden = true
        }
        if countdown == 0
        {
            countdownLabel.text = "GO!!!"
            startTimer(2)
        }
        else
        {
            countdownLabel.text = String(countdown)
            startTimer(1)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Generate a random board
    }
    
    func oneButtonAlert()
    {
        // construct an alert
        let alert = UIAlertController(title: "Winner",
            message: "Congrats you win!",
            preferredStyle: UIAlertControllerStyle.Alert)

        // create a button for that alert
        let ok = UIAlertAction(title: "K, whatevs", style: .Default)
            { (action) in
                println("Ambivalence detected")
            }

        // link OK button to alert
        alert.addAction(ok)

        // show the alert
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func twoButtonAlert()
    {
        // construct an alert
        let alert = UIAlertController(title: "Shuffle?",
            message: "Do you want to shuffle the board?",
            preferredStyle: UIAlertControllerStyle.Alert)

        // create a button for that alert
        let ok = UIAlertAction(title: "Um yes", style: .Default)
            { (action) in
                println("Shuffle requested")
            }

        // link OK button to alert
        alert.addAction(ok)

        // create a button for that alert
        let cancel = UIAlertAction(title: "ABORT!!!", style: .Cancel)
            { (action) in
                println("Cancel requested")
            }

        // link OK button to alert
        alert.addAction(cancel)

        // show the alert
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func threeButtonActionSheet()
    {
        // construct an Action sheet
        let alert = UIAlertController(title: nil,
            message: "What difficulty would you like?",
            preferredStyle: UIAlertControllerStyle.ActionSheet)
        
        // create buttons and add them to the sheet
        let cancel = UIAlertAction(title: "Cancel", style: .Cancel)
            { (action) in
                return
        }
        alert.addAction(cancel)
        
        let easy = UIAlertAction(title: "Easy", style: .Default)
            { (action) in
                println("User wants a board that's quick to solve!")
        }
        alert.addAction(easy)
        
        let med = UIAlertAction(title: "Med", style: .Default)
            { (action) in
                println("User wants a board with medium difficulty!")
        }
        alert.addAction(med)
        
        let hard = UIAlertAction(title: "Hard", style: .Default)
            { (action) in
                println("User wants a difficult board!")
        }
        alert.addAction(hard)
        
        // show the alert
        self.presentViewController(alert, animated: true, completion: nil)
    }
    
    func tileTapped(sender: UIButton)
    {
        
        if animating
        {
            println("tileTapped: animating!! abort mission!!!")
            return
        }
        
        println("tileTapped: \(sender.tag)")
        
        // ok we're going to swap tiles now!!!!
        animating = true
        
        // find the two tiles I want to swap
        let tile0 = boardView.viewWithTag(0)!
        let tile1 = boardView.viewWithTag(1)!
        
        // obtain their frames
        let frame0 = tile0.frame
        let frame1 = tile1.frame
        
        UIView.animateWithDuration(4, animations:
        { () -> Void in
            // swap the frames to swap their positions on screen
            tile0.frame = frame1
            tile1.frame = frame0
        }, completion: { ((Bool)) -> Void in
            println("tileTapped: animation complete!")
            self.animating = false
        })

    }
    
    override func viewDidAppear(animated: Bool)
    {
        let tileSize = round((boardView.bounds.size.width - CGFloat(16.0)) / 4.0)

        for i in 0 ... 1
        {
            let rect = CGRect(x: tileSize*CGFloat(i), y: 0.0, width: tileSize, height: tileSize)
            
            var newTile = UIButton(frame: rect)
            
            // set the caption of the button
            newTile.setTitle(String(i), forState: UIControlState.Normal)
            
            // let the button know which tile it is
            newTile.tag = i
            
            // change the background color of the tile
            newTile.backgroundColor = UIColor.lightGrayColor()
            
            // set a border
            newTile.layer.borderColor = UIColor.blackColor().CGColor
            newTile.layer.borderWidth = 2
            
            // add a shadow!!!!!
            newTile.layer.shadowRadius = 2
            newTile.layer.shadowColor = UIColor.blackColor().CGColor
            newTile.layer.shadowOffset = CGSizeMake(2.0, 2.0)
            newTile.layer.shadowOpacity = 0.5
            
            newTile.addTarget(self, action: "tileTapped:", forControlEvents: UIControlEvents.TouchUpInside)
            
            // remember this tile for later use
            tiles.append(newTile)
            
            // add the tile to the board
            boardView.addSubview(newTile)
        }
        
        countdownLabel.text = String(countdown)
        startTimer(1)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

